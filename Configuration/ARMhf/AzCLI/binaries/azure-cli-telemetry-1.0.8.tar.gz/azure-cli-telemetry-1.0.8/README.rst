Microsoft Azure CLI Telemetry Package
=====================================

This is the Microsoft Azure CLI Telemetry package. It is not intended to be installed directly by the end user.

This package includes:
1. Support API for Azure CLI to gather telemetry.
2. Telemetry upload process.

