.. :changelog:

Release History
===============
1.0.8
+++++
* Keep storing telemetry to CLI AppInsights in local cache but send telemetry to other AppInsights immediately

1.0.7
+++++
* Support specifying `telemetry.push_interval_in_hours` to force push telemetry cache file

1.0.6
+++++
* Add `__version__` in `__init__.py`

1.0.5
+++++
* Support PEP420 namespace package

1.0.4
+++++
* MANIFEST file change to fix wheel install

1.0.3
+++++
* Indicate Python 3.7 support

1.0.2
+++++
* Minor fixes

1.0.1
+++++
* Minor fixes

1.0.0
+++++
* Initialize the azure-cli-telemetry package.
